# -*- coding: utf-8 -*-
"""
=============================
A basic example
=============================

Add some more text here.
"""

# Code source: Andrew Heusser
# License: MIT

# import
import cdl

# run
list1 = [1, 2, 3]
list2 = [4, 5, 6]
print(cdl.add_lists(list1, list2))
