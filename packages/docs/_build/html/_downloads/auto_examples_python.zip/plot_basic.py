# -*- coding: utf-8 -*-
"""
=============================
A basic example
=============================

Add some more text here.
"""

# Code source: Andrew Heusser
# License: MIT

# import
import cdl

# run
print(cdl.chatter())
